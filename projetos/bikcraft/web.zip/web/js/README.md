# CSS
 O arquivo simple-slide.js não foi de minha autoria.<br><br>
 Segundo o autor do curso, os códigos gerados neste arquivo serão ensinados no curso de Javascript Completo ES6+.