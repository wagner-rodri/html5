# CSS
 Os arquivos de nome style e responsivo  foram totalmente editados por mim, neles pude aprender o básico de CSS.<br>
 Os arquivos normalize.css e reset.css foram adicionados ao projeto como padrões para serem utilizados no site e não foram de minha autoria. O arquivo grid.css foi adicionado ao projeto, mas a seção @media foi editada por mim.<br>
 Estes arquivos adicionados foram considerados não adequados para serem ensinados pelo autor do curso, pois suas características devem ser ensinadas em cursos específicos de CSS a parte do curso de Web Designer. <br>
 Estes cursos serão os próximos passos que tomarei para fixar de forma adequada meus conhecimentos de estilização em CSS.